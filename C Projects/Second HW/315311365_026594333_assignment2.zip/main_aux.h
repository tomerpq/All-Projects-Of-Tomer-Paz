#ifndef MAIN_AUX_H_
#define MAIN_AUX_H_
void checkN(int n);
void printHeaps(int heaps[],int n,int turn);
int checkObjToRemoveBad(int heaps[],int n,int index,int toRemove);
int checkPos(int c);

#endif /* MAIN_AUX_H_ */

