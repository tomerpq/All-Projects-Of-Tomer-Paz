#ifndef SP_NIM_H_
#define SP_NIM_H_
int askHeapsNumberAndSizes(int heaps[]);
void checkIfWin(int heaps[],int n,int userTurn);
void userTurnMethod(int heaps[],int n);
void computerTurnMethod(int heaps[],int n);

#endif /* SP_NIM_H_ */
