package il.ac.tau.cs.sw1.hw3;

public class ArrayUtils {
	
	public static int[] reverseArray(int[] array)
	{
		//TODO
		return array;
		
	}
	
	public static int[] shiftArrayToTheRightCyclic(int[] array, int move)
	{
		//TODO
		return array;
		
	}
	
	public static int alternateSum(int[] array)
	{
		//TODO
		return 0;
		
	}
	
	public static int findPath(int[][] m, int i, int j)
	{
		//TODO
		return 0;
		
	}

}
