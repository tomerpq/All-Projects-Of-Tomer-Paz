package il.ac.tau.cs.sw1.ex9.riddles.second;

public class B2 {
	
}
