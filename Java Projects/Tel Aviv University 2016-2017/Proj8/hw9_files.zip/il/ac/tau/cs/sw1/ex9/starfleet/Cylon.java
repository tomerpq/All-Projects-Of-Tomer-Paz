package il.ac.tau.cs.sw1.ex9.starfleet;

public class Cylon {

	public Cylon(String name, int age, int yearsInService, int modelNumber) {
		
	}
	

}
