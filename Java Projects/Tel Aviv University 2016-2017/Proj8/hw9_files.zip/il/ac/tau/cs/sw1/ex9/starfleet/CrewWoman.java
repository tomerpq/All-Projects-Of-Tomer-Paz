package il.ac.tau.cs.sw1.ex9.starfleet;

public class CrewWoman {

	
	public CrewWoman(String name, int age, int yearsInService){
		
	}

}
