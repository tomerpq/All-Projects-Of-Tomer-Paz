package il.ac.tau.cs.sw1.ex9.riddles.third;

public class B3 {
	
}