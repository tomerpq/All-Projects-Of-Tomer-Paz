package il.ac.tau.cs.sw1.ex9.riddles.second;

public class A2 {

	public String foo(String s) {
		return s.toLowerCase();
	}
}
