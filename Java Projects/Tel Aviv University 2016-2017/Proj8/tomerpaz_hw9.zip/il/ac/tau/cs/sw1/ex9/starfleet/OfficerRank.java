package il.ac.tau.cs.sw1.ex9.starfleet;

public enum OfficerRank {
	Ensign,
	Lieutenant,
	LieutenantCommander,
	Commander,
	Captain,
	Admiral;
}
