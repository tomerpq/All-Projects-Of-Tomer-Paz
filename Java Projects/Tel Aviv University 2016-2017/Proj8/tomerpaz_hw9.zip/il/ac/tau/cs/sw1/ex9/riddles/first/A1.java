package il.ac.tau.cs.sw1.ex9.riddles.first;

public class A1 {
	protected boolean foo() {
		return true;
	}
}
