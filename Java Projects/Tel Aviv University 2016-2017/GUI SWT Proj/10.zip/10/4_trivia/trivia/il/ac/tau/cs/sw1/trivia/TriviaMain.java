package il.ac.tau.cs.sw1.trivia;

public class TriviaMain {

	/**
	 * Execute to play trivia!
	 */
	public static void main(String[] args) {
		TriviaGUI gui = new TriviaGUI();
		gui.open();
	}

}
