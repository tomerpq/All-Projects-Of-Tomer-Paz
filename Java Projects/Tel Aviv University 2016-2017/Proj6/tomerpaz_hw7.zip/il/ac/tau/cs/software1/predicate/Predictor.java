package il.ac.tau.cs.software1.predicate;

public interface Predictor {
	
	 public boolean test(Object o);

}
