package il.ac.tau.cs.sw1.ex8.histogram;

import java.util.Iterator;


/**************************************
 *  Add your code to this class !!!   *
 **************************************/
public class HashMapHistogramIterator<T extends Comparable<T>> implements Iterator<T>{
	

	
	
	@Override
	public boolean hasNext() {
		//your code goes here!
		return false; //replace this with the actual returned value
	}

	@Override
	public T next() {
		//your code goes here!
		return null; //replace this with the actual returned value
	}

	@Override
	public void remove() {
		throw new UnsupportedOperationException();
	}
}
