package il.ac.tau.cs.sw1.ex8.wordsRank;

import java.util.Comparator;

import il.ac.tau.cs.sw1.ex8.wordsRank.RankedWord.rankType;


/**************************************
 *  Add your code to this class !!!   *
 **************************************/

class RankedWordComparator implements Comparator<RankedWord>{
	public RankedWordComparator(rankType cType) {
		//your code goes here!
	}
	
	@Override
	public int compare(RankedWord o1, RankedWord o2) {
		//your code goes here!
		return 0; //replace this with the actual returned value
	}	
}
