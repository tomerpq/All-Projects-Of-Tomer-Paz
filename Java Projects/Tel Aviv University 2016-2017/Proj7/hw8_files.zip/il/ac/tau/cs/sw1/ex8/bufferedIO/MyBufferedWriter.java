package il.ac.tau.cs.sw1.ex8.bufferedIO;

import java.io.FileWriter;
import java.io.IOException;


/**************************************
 *  Add your code to this class !!!   *
 **************************************/

public class MyBufferedWriter implements IBufferedWriter{
	

	public MyBufferedWriter(FileWriter fWriter, int bufferSize){
		//your code goes here!
	}

	
	@Override
	public void write(String str) throws IOException {
		//your code goes here!

	}
	
	@Override
	public void close() throws IOException {
		//your code goes here!
	}

}
